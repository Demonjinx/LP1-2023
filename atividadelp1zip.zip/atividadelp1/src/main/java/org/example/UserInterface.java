package org.example;
import java.util.Scanner;

interface UserInterface {
    void displayMenu();
    void run();
}